//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Tool.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MODELTYPE                   129
#define IDC_CURSOR_ROTATION             131
#define IDD_FORM_COMMAND                150
#define IDC_FRAME_COLOR_BACK            1000
#define IDC_CHECK_ANTIALIAS             1001
#define IDC_CHECK_SMOOTH                1002
#define IDC_RADIO_MODEL_1               1003
#define IDC_CHECK_LIGHTING              1004
#define IDC_RADIO_MODEL_2               1005
#define IDC_RADIO_MODEL_0               1006
#define IDC_CHECK_VROTATION             1007
#define IDC_SLIDER_X                    1008
#define IDC_CHECK_LINK_SCALE            1009
#define IDC_FRAME_COLOR_LIGHT_AMBIENT   1010
#define IDC_SLIDER_Y                    1011
#define IDC_SLIDER_Z                    1012
#define IDC_FRAME_COLOR_LIGHT_AMBIENT2  1013
#define IDC_FRAME_COLOR_LIGHT_AMBIENT3  1014
#define IDC_TIME                        1015
#define IDC_TIME1                       1017
#define IDC_TIME2                       1019
#define IDC_TIME3                       1020
#define IDC_TIME4                       1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
